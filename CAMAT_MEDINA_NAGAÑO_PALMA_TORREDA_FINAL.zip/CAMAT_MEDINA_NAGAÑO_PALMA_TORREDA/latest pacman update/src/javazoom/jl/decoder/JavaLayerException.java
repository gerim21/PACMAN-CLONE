package javazoom.jl.decoder;

public record JavaLayerException() {

	public void printStackTrace() {
		// TODO Auto-generated method stub
		
	}

}
