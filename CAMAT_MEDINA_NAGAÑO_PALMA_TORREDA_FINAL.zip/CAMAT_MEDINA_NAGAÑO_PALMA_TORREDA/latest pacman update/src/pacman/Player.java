package pacman;

public record Player() {

	public void play() {
		// TODO Auto-generated method stub
		
	}

}
